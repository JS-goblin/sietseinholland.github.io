using System.Globalization;

namespace assignment8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // set culture of program
            CultureInfo ci = new CultureInfo("en-US");
            Thread.CurrentThread.CurrentUICulture = ci;
            Thread.CurrentThread.CurrentCulture = ci;
            // your code here...

            label7.Text = DateTime.Now.ToString();
        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            const double VATprecent = 0.21;
            int num_shirt = int.Parse(textBox1.Text);
            int num_jean = int.Parse(textBox2.Text);

            int price = (num_jean * 100) + (num_shirt * 30);
            double VAT = price * VATprecent;
            double total = price + VAT;

            label8.Text = "$ " + price.ToString();
            label9.Text = "$ " + Math.Round(VAT,2).ToString();
            label10.Text = "$ " + Math.Round(total,2).ToString();
        }
    }
}