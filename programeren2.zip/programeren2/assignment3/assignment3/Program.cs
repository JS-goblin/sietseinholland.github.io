﻿using System;
using System.Globalization;
using System.Threading;

namespace assignment3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // set culture of program
            CultureInfo ci = new CultureInfo("en-US");
            Thread.CurrentThread.CurrentUICulture = ci;
            Thread.CurrentThread.CurrentCulture = ci;
            // your code here...

            Console.Write("Enter numbers of seconds: ");
            int inputsec = int.Parse(Console.ReadLine());
            int hours = inputsec / 3600;
            int minutes = inputsec % 3600 / 60;
            int seconds = inputsec % 3600 % 60;

            Console.WriteLine($"Time = {hours}:{minutes}:{seconds}");

        }
    }
}