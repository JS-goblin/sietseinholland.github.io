using System.Globalization;

namespace assignment7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            CultureInfo ci = new CultureInfo("en-US");
            Thread.CurrentThread.CurrentUICulture = ci;
            Thread.CurrentThread.CurrentCulture = ci;


        }

        private void button2_Click(object sender, EventArgs e)
        {
            int Start_KM = int.Parse(textBox1.Text);
            int End_KM = int.Parse(textBox2.Text);
            double Price_per_KM = double.Parse(textBox3.Text);
            const double VATprecentage = 0.21;

            double price = (End_KM - Start_KM) * Price_per_KM;

            double VAT = price * VATprecentage;
            double total = price + VAT;

            label7.Text = Math.Round(price ,2).ToString();
            label8.Text = Math.Round(VAT ,2).ToString();
            label9.Text = Math.Round(total ,2).ToString();



        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";

            label7.Text = "";
            label8.Text = "";
            label9.Text = "";
        }

    }
}