using System.Globalization;

namespace assignment6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // set culture of program
            CultureInfo ci = new CultureInfo("en-US");
            Thread.CurrentThread.CurrentUICulture = ci;
            Thread.CurrentThread.CurrentCulture = ci;
            // your code here...

            Console.Write("Enter numbers of seconds: ");
            int inputsec = int.Parse(Seconds_box.Text);
            int hours = inputsec / 3600;
            int minutes = inputsec % 3600 / 60;
            int seconds = inputsec % 3600 % 60;

            Time.Text =  $"{hours}:{minutes}:{seconds}";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}