﻿namespace assignment6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label1 = new Label();
            Seconds_box = new TextBox();
            label2 = new Label();
            Time = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(93, 81);
            button1.Name = "button1";
            button1.Size = new Size(104, 23);
            button1.TabIndex = 0;
            button1.Text = "callculate time";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(41, 35);
            label1.Name = "label1";
            label1.Size = new Size(54, 15);
            label1.TabIndex = 1;
            label1.Text = "Seconds:";
            label1.Click += label1_Click;
            // 
            // Seconds_box
            // 
            Seconds_box.Location = new Point(97, 32);
            Seconds_box.Name = "Seconds_box";
            Seconds_box.Size = new Size(100, 23);
            Seconds_box.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(41, 125);
            label2.Name = "label2";
            label2.Size = new Size(36, 15);
            label2.TabIndex = 3;
            label2.Text = "Time:";
            // 
            // Time
            // 
            Time.AutoSize = true;
            Time.Location = new Point(123, 125);
            Time.Name = "Time";
            Time.Size = new Size(33, 15);
            Time.TabIndex = 4;
            Time.Text = "Time";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(294, 216);
            Controls.Add(Time);
            Controls.Add(label2);
            Controls.Add(Seconds_box);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private TextBox Seconds_box;
        private Label label2;
        private Label Time;
    }
}