using System.Globalization;

namespace assignment5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // set culture of program
            CultureInfo ci = new CultureInfo("en-US");
            Thread.CurrentThread.CurrentUICulture = ci;
            Thread.CurrentThread.CurrentCulture = ci;
            // your code here...

            int[] numbers = new int[3];

            Console.Write("enter number: ");
            numbers[0] = int.Parse(num1.Text);

            Console.Write("enter number: ");
            numbers[1] = int.Parse(num2.Text);

            Console.Write("enter number: ");
            numbers[2] = int.Parse(num3.Text);

            average_output.Text = Math.Round(numbers.Average() , 3).ToString();

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}