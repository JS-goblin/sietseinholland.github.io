using System.Globalization;

namespace assignment4
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
            // set culture of program
            CultureInfo ci = new CultureInfo("en-US");
            Thread.CurrentThread.CurrentUICulture = ci;
            Thread.CurrentThread.CurrentCulture = ci;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            double VATprecentage = 0.21;
            double price = double.Parse(textBox1.Text);



            Console.WriteLine("enter price");
            double VAT = price * VATprecentage;
            double total = price + VAT;


            price_output.Text = Math.Round(price, 2).ToString();
            VAT_output.Text = Math.Round(VAT, 2).ToString();
            Total_output.Text = Math.Round(total, 2).ToString();


        }
    }
}