﻿namespace assignment4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button1 = new Button();
            textBox1 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            price_output = new Label();
            VAT_output = new Label();
            Total_output = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(34, 31);
            label1.Name = "label1";
            label1.Size = new Size(75, 15);
            label1.TabIndex = 0;
            label1.Text = "Enter a price:";
            // 
            // button1
            // 
            button1.Location = new Point(80, 78);
            button1.Name = "button1";
            button1.Size = new Size(135, 23);
            button1.TabIndex = 1;
            button1.Text = "Determine VAT";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(115, 28);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(34, 115);
            label2.Name = "label2";
            label2.Size = new Size(36, 15);
            label2.TabIndex = 3;
            label2.Text = "Price:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(34, 149);
            label3.Name = "label3";
            label3.Size = new Size(29, 15);
            label3.TabIndex = 4;
            label3.Text = "VAT:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(34, 182);
            label4.Name = "label4";
            label4.Size = new Size(35, 15);
            label4.TabIndex = 5;
            label4.Text = "Total:";
            // 
            // price_output
            // 
            price_output.AutoSize = true;
            price_output.Location = new Point(152, 115);
            price_output.Name = "price_output";
            price_output.Size = new Size(33, 15);
            price_output.TabIndex = 6;
            price_output.Text = "price";
            // 
            // VAT_output
            // 
            VAT_output.AutoSize = true;
            VAT_output.Location = new Point(152, 149);
            VAT_output.Name = "VAT_output";
            VAT_output.Size = new Size(26, 15);
            VAT_output.TabIndex = 7;
            VAT_output.Text = "VAT";
            // 
            // Total_output
            // 
            Total_output.AutoSize = true;
            Total_output.Location = new Point(152, 182);
            Total_output.Name = "Total_output";
            Total_output.Size = new Size(32, 15);
            Total_output.TabIndex = 8;
            Total_output.Text = "Total";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(256, 212);
            Controls.Add(Total_output);
            Controls.Add(VAT_output);
            Controls.Add(price_output);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(button1);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Enter a price:";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button1;
        private TextBox textBox1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label price_output;
        private Label VAT_output;
        private Label Total_output;
    }
}