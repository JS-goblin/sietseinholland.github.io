﻿using System;
using System.Globalization;
using System.Threading;

namespace assignment2
{
    internal class Program
    {

        static void Main(string[] args)
        {
            // set culture of program
            CultureInfo ci = new CultureInfo("en-US");
            Thread.CurrentThread.CurrentUICulture = ci;
            Thread.CurrentThread.CurrentCulture = ci;
            // your code here...

            int[] numbers = new int[3];

            Console.Write("enter number: ");
            numbers[0] = int.Parse(Console.ReadLine());

            Console.Write("enter number: ");
            numbers[1] = int.Parse(Console.ReadLine());

            Console.Write("enter number: ");
            numbers[2] = int.Parse(Console.ReadLine());

            Console.WriteLine($"average is : {numbers.Average()}");
        }
}
}