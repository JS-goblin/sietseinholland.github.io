﻿using System;
using System.Globalization;
using System.Threading;

namespace assignment1
{
    internal class Program
    {
        const double VATrate = 0.21;
        static void Main(string[] args)
        {
            

            // set culture of program
            CultureInfo ci = new CultureInfo("en-US");
            Thread.CurrentThread.CurrentUICulture = ci;
            Thread.CurrentThread.CurrentCulture = ci;


            Console.WriteLine("enter price");
            double price = double.Parse(Console.ReadLine());
            double VAT = price * VATrate;
            double total = price + VAT;

            Console.WriteLine($"Price: {price}, VAT: {VAT:0.00},Total: {price + VAT:0.00}");


        }
}
}